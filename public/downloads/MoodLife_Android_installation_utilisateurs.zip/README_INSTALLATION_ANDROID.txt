Mood Life - Installation Android

Fichier a donner aux testeurs : MoodLife.apk

Installation :
1. Transfere MoodLife.apk sur le telephone Android.
2. Ouvre le fichier depuis le telephone.
3. Android peut demander d'autoriser l'installation depuis cette source.
4. Accepte, puis installe Mood Life.
5. Lance l'application.

Important :
- Ne donne PAS aux utilisateurs les fichiers signing.keystore, signing-key-info.txt ou Mood Life.aab.
- Le fichier .aab sert plutot a publier sur Google Play.
- Pour que l'app Android s'ouvre en plein ecran correctement, le fichier assetlinks.json doit etre publie sur ton site Vercel dans :
  https://ton-url-vercel.vercel.app/.well-known/assetlinks.json
