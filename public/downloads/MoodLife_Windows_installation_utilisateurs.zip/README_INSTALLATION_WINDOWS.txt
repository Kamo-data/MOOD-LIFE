Mood Life - Installation Windows

Option simple :
1. Decompresse ce dossier.
2. Double-clique sur Setup-MoodLife.exe.
3. Si Windows affiche une alerte SmartScreen, clique sur Informations complementaires puis Executer quand meme, uniquement si tu fais confiance a la source.
4. Cherche ensuite Mood Life dans le menu Demarrer.

Option de secours :
1. Si Setup-MoodLife.exe ne fonctionne pas, double-clique sur MoodLife.sideload.msix.
2. Si Windows refuse encore l'installation, essaie MoodLife.msixbundle.

Notes :
- Ces fichiers viennent du package Windows genere par PWABuilder.
- Sans certificat de signature officiel, Windows peut afficher des avertissements. C'est normal pour une version beta distribuee hors Microsoft Store.
- Pour une distribution plus professionnelle, il faudra soit publier via Microsoft Store, soit signer le package avec un certificat de confiance.
